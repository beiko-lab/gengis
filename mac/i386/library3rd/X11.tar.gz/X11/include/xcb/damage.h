/*
 * This file generated automatically from damage.xml by c-client.xsl using XSLT.
 * Edit at your peril.
 */

/**
 * @defgroup XCB_Damage_API XCB Damage API
 * @brief Damage XCB Protocol Implementation.
 * @{
 **/

#ifndef __DAMAGE_H
#define __DAMAGE_H

#include "xcb.h"
#include "xproto.h"
#include "xfixes.h"

#define XCB_DAMAGE_MAJOR_VERSION 1
#define XCB_DAMAGE_MINOR_VERSION 0
  
extern xcb_extension_t xcb_damage_id;

typedef uint32_t xcb_damage_damage_t;

/**
 * @brief xcb_damage_damage_iterator_t
 **/
typedef struct xcb_damage_damage_iterator_t {
    xcb_damage_damage_t *data; /**<  */
    int                  rem; /**<  */
    int                  index; /**<  */
} xcb_damage_damage_iterator_t;

typedef enum xcb_damage_report_level_t {
    XCB_DAMAGE_REPORT_LEVEL_RAW_RECTANGLES,
    XCB_DAMAGE_REPORT_LEVEL_DELTA_RECTANGLES,
    XCB_DAMAGE_REPORT_LEVEL_BOUNDING_BOX,
    XCB_DAMAGE_REPORT_LEVEL_NON_EMPTY
} xcb_damage_report_level_t;

/** Opcode for xcb_damage_bad_damage. */
#define XCB_DAMAGE_BAD_DAMAGE 0

/**
 * @brief xcb_damage_bad_damage_error_t
 **/
typedef struct xcb_damage_bad_damage_error_t {
    uint8_t  response_type; /**<  */
    uint8_t  error_code; /**<  */
    uint16_t sequence; /**<  */
} xcb_damage_bad_damage_error_t;

/**
 * @brief xcb_damage_query_version_cookie_t
 **/
typedef struct xcb_damage_query_version_cookie_t {
    unsigned int sequence; /**<  */
} xcb_damage_query_version_cookie_t;

/** Opcode for xcb_damage_query_version. */
#define XCB_DAMAGE_QUERY_VERSION 0

/**
 * @brief xcb_damage_query_version_request_t
 **/
typedef struct xcb_damage_query_version_request_t {
    uint8_t  major_opcode; /**<  */
    uint8_t  minor_opcode; /**<  */
    uint16_t length; /**<  */
    uint32_t client_major_version; /**<  */
    uint32_t client_minor_version; /**<  */
} xcb_damage_query_version_request_t;

/**
 * @brief xcb_damage_query_version_reply_t
 **/
typedef struct xcb_damage_query_version_reply_t {
    uint8_t  response_type; /**<  */
    uint8_t  pad0; /**<  */
    uint16_t sequence; /**<  */
    uint32_t length; /**<  */
    uint32_t major_version; /**<  */
    uint32_t minor_version; /**<  */
    uint8_t  pad1[16]; /**<  */
} xcb_damage_query_version_reply_t;

/** Opcode for xcb_damage_create. */
#define XCB_DAMAGE_CREATE 1

/**
 * @brief xcb_damage_create_request_t
 **/
typedef struct xcb_damage_create_request_t {
    uint8_t             major_opcode; /**<  */
    uint8_t             minor_opcode; /**<  */
    uint16_t            length; /**<  */
    xcb_damage_damage_t damage; /**<  */
    xcb_drawable_t      drawable; /**<  */
    uint8_t             level; /**<  */
    uint8_t             pad0[3]; /**<  */
} xcb_damage_create_request_t;

/** Opcode for xcb_damage_destroy. */
#define XCB_DAMAGE_DESTROY 2

/**
 * @brief xcb_damage_destroy_request_t
 **/
typedef struct xcb_damage_destroy_request_t {
    uint8_t             major_opcode; /**<  */
    uint8_t             minor_opcode; /**<  */
    uint16_t            length; /**<  */
    xcb_damage_damage_t damage; /**<  */
} xcb_damage_destroy_request_t;

/** Opcode for xcb_damage_subtract. */
#define XCB_DAMAGE_SUBTRACT 3

/**
 * @brief xcb_damage_subtract_request_t
 **/
typedef struct xcb_damage_subtract_request_t {
    uint8_t             major_opcode; /**<  */
    uint8_t             minor_opcode; /**<  */
    uint16_t            length; /**<  */
    xcb_damage_damage_t damage; /**<  */
    xcb_xfixes_region_t repair; /**<  */
    xcb_xfixes_region_t parts; /**<  */
} xcb_damage_subtract_request_t;

/** Opcode for xcb_damage_notify. */
#define XCB_DAMAGE_NOTIFY 0

/**
 * @brief xcb_damage_notify_event_t
 **/
typedef struct xcb_damage_notify_event_t {
    uint8_t             response_type; /**<  */
    uint8_t             level; /**<  */
    uint16_t            sequence; /**<  */
    xcb_drawable_t      drawable; /**<  */
    xcb_damage_damage_t damage; /**<  */
    xcb_timestamp_t     timestamp; /**<  */
    xcb_rectangle_t     area; /**<  */
    xcb_rectangle_t     geometry; /**<  */
} xcb_damage_notify_event_t;


/*****************************************************************************
 **
 ** void xcb_damage_damage_next
 ** 
 ** @param xcb_damage_damage_iterator_t *i
 ** @returns void
 **
 *****************************************************************************/
 
void
xcb_damage_damage_next (xcb_damage_damage_iterator_t *i  /**< */);


/*****************************************************************************
 **
 ** xcb_generic_iterator_t xcb_damage_damage_end
 ** 
 ** @param xcb_damage_damage_iterator_t i
 ** @returns xcb_generic_iterator_t
 **
 *****************************************************************************/
 
xcb_generic_iterator_t
xcb_damage_damage_end (xcb_damage_damage_iterator_t i  /**< */);


/*****************************************************************************
 **
 ** xcb_damage_query_version_cookie_t xcb_damage_query_version
 ** 
 ** @param xcb_connection_t *c
 ** @param uint32_t          client_major_version
 ** @param uint32_t          client_minor_version
 ** @returns xcb_damage_query_version_cookie_t
 **
 *****************************************************************************/
 
xcb_damage_query_version_cookie_t
xcb_damage_query_version (xcb_connection_t *c  /**< */,
                          uint32_t          client_major_version  /**< */,
                          uint32_t          client_minor_version  /**< */);


/*****************************************************************************
 **
 ** xcb_damage_query_version_cookie_t xcb_damage_query_version_unchecked
 ** 
 ** @param xcb_connection_t *c
 ** @param uint32_t          client_major_version
 ** @param uint32_t          client_minor_version
 ** @returns xcb_damage_query_version_cookie_t
 **
 *****************************************************************************/
 
xcb_damage_query_version_cookie_t
xcb_damage_query_version_unchecked (xcb_connection_t *c  /**< */,
                                    uint32_t          client_major_version  /**< */,
                                    uint32_t          client_minor_version  /**< */);


/*****************************************************************************
 **
 ** xcb_damage_query_version_reply_t * xcb_damage_query_version_reply
 ** 
 ** @param xcb_connection_t                   *c
 ** @param xcb_damage_query_version_cookie_t   cookie
 ** @param xcb_generic_error_t               **e
 ** @returns xcb_damage_query_version_reply_t *
 **
 *****************************************************************************/
 
xcb_damage_query_version_reply_t *
xcb_damage_query_version_reply (xcb_connection_t                   *c  /**< */,
                                xcb_damage_query_version_cookie_t   cookie  /**< */,
                                xcb_generic_error_t               **e  /**< */);


/*****************************************************************************
 **
 ** xcb_void_cookie_t xcb_damage_create_checked
 ** 
 ** @param xcb_connection_t    *c
 ** @param xcb_damage_damage_t  damage
 ** @param xcb_drawable_t       drawable
 ** @param uint8_t              level
 ** @returns xcb_void_cookie_t
 **
 *****************************************************************************/
 
xcb_void_cookie_t
xcb_damage_create_checked (xcb_connection_t    *c  /**< */,
                           xcb_damage_damage_t  damage  /**< */,
                           xcb_drawable_t       drawable  /**< */,
                           uint8_t              level  /**< */);


/*****************************************************************************
 **
 ** xcb_void_cookie_t xcb_damage_create
 ** 
 ** @param xcb_connection_t    *c
 ** @param xcb_damage_damage_t  damage
 ** @param xcb_drawable_t       drawable
 ** @param uint8_t              level
 ** @returns xcb_void_cookie_t
 **
 *****************************************************************************/
 
xcb_void_cookie_t
xcb_damage_create (xcb_connection_t    *c  /**< */,
                   xcb_damage_damage_t  damage  /**< */,
                   xcb_drawable_t       drawable  /**< */,
                   uint8_t              level  /**< */);


/*****************************************************************************
 **
 ** xcb_void_cookie_t xcb_damage_destroy_checked
 ** 
 ** @param xcb_connection_t    *c
 ** @param xcb_damage_damage_t  damage
 ** @returns xcb_void_cookie_t
 **
 *****************************************************************************/
 
xcb_void_cookie_t
xcb_damage_destroy_checked (xcb_connection_t    *c  /**< */,
                            xcb_damage_damage_t  damage  /**< */);


/*****************************************************************************
 **
 ** xcb_void_cookie_t xcb_damage_destroy
 ** 
 ** @param xcb_connection_t    *c
 ** @param xcb_damage_damage_t  damage
 ** @returns xcb_void_cookie_t
 **
 *****************************************************************************/
 
xcb_void_cookie_t
xcb_damage_destroy (xcb_connection_t    *c  /**< */,
                    xcb_damage_damage_t  damage  /**< */);


/*****************************************************************************
 **
 ** xcb_void_cookie_t xcb_damage_subtract_checked
 ** 
 ** @param xcb_connection_t    *c
 ** @param xcb_damage_damage_t  damage
 ** @param xcb_xfixes_region_t  repair
 ** @param xcb_xfixes_region_t  parts
 ** @returns xcb_void_cookie_t
 **
 *****************************************************************************/
 
xcb_void_cookie_t
xcb_damage_subtract_checked (xcb_connection_t    *c  /**< */,
                             xcb_damage_damage_t  damage  /**< */,
                             xcb_xfixes_region_t  repair  /**< */,
                             xcb_xfixes_region_t  parts  /**< */);


/*****************************************************************************
 **
 ** xcb_void_cookie_t xcb_damage_subtract
 ** 
 ** @param xcb_connection_t    *c
 ** @param xcb_damage_damage_t  damage
 ** @param xcb_xfixes_region_t  repair
 ** @param xcb_xfixes_region_t  parts
 ** @returns xcb_void_cookie_t
 **
 *****************************************************************************/
 
xcb_void_cookie_t
xcb_damage_subtract (xcb_connection_t    *c  /**< */,
                     xcb_damage_damage_t  damage  /**< */,
                     xcb_xfixes_region_t  repair  /**< */,
                     xcb_xfixes_region_t  parts  /**< */);


#endif

/**
 * @}
 */
