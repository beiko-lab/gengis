#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/accel.h"
#else
#include "wx/mac/carbon/accel.h"
#endif
