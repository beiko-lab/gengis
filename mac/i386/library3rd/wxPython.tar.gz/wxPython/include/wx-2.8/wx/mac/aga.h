/////////////////////////////////////////////////////////////////////////////
// Name:        aga.h
// Purpose:     Gray Controls implementation
// Author:      Stefan Csomor
// Modified by:
// Created:     1998-01-01
// RCS-ID:      $Id: aga.h 31782 2005-02-06 11:29:39Z SC $
// Copyright:   (c) Stefan Csomor
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////


// NOT NEEDED ANYMORE
