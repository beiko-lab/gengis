#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/bmpbuttn.h"
#else
#include "wx/mac/carbon/bmpbuttn.h"
#endif
