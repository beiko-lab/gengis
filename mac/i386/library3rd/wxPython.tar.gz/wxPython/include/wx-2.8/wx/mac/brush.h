#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/brush.h"
#else
#include "wx/mac/carbon/brush.h"
#endif
