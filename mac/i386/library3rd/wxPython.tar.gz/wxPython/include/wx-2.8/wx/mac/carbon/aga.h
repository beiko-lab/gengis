/////////////////////////////////////////////////////////////////////////////
// Name:        aga.h
// Purpose:     Gray Controls implementation
// Author:      Stefan Csomor
// Modified by:
// Created:     1998-01-01
// RCS-ID:      $Id: aga.h 27408 2004-05-23 20:53:33Z JS $
// Copyright:   (c) Stefan Csomor
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////


// NOT NEEDED ANYMORE