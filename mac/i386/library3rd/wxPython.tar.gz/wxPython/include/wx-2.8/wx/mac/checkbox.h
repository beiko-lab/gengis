#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/checkbox.h"
#else
#include "wx/mac/carbon/checkbox.h"
#endif
