#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/checklst.h"
#else
#include "wx/mac/carbon/checklst.h"
#endif
