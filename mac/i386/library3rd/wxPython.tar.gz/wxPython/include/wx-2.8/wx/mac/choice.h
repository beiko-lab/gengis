#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/choice.h"
#else
#include "wx/mac/carbon/choice.h"
#endif
