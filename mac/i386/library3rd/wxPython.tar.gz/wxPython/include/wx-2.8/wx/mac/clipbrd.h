#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/clipbrd.h"
#else
#include "wx/mac/carbon/clipbrd.h"
#endif
