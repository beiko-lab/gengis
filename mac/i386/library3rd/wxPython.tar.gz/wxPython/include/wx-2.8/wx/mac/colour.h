#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/colour.h"
#else
#include "wx/mac/carbon/colour.h"
#endif
