#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/combobox.h"
#else
#include "wx/mac/carbon/combobox.h"
#endif
