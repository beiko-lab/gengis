#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/control.h"
#else
#include "wx/mac/carbon/control.h"
#endif
