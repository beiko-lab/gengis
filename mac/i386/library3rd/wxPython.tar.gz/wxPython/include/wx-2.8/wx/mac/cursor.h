#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/cursor.h"
#else
#include "wx/mac/carbon/cursor.h"
#endif
