#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dataobj2.h"
#else
#include "wx/mac/carbon/dataobj2.h"
#endif
