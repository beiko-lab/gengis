#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dc.h"
#else
#include "wx/mac/carbon/dc.h"
#endif
