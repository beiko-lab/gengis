#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dcclient.h"
#else
#include "wx/mac/carbon/dcclient.h"
#endif
