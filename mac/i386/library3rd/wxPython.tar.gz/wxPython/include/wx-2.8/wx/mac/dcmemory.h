#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dcmemory.h"
#else
#include "wx/mac/carbon/dcmemory.h"
#endif
