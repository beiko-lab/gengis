#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dcscreen.h"
#else
#include "wx/mac/carbon/dcscreen.h"
#endif
