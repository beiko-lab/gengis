#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dialog.h"
#else
#include "wx/mac/carbon/dialog.h"
#endif
