#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/dnd.h"
#else
#include "wx/mac/carbon/dnd.h"
#endif
