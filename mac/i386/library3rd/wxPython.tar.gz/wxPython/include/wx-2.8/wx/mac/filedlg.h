#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/filedlg.h"
#else
#include "wx/mac/carbon/filedlg.h"
#endif
