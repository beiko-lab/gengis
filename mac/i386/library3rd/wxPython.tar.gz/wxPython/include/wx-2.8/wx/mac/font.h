#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/font.h"
#else
#include "wx/mac/carbon/font.h"
#endif
