#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/fontdlg.h"
#else
#include "wx/mac/carbon/fontdlg.h"
#endif
