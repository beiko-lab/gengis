#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/frame.h"
#else
#include "wx/mac/carbon/frame.h"
#endif
