#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/gauge.h"
#else
#include "wx/mac/carbon/gauge.h"
#endif
