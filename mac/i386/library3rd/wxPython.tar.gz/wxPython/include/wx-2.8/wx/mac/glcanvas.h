#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/glcanvas.h"
#else
#include "wx/mac/carbon/glcanvas.h"
#endif