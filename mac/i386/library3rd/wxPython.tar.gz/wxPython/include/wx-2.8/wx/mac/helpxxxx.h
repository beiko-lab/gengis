#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/helpxxxx.h"
#else
#include "wx/mac/carbon/helpxxxx.h"
#endif