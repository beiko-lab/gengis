#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/icon.h"
#else
#include "wx/mac/carbon/icon.h"
#endif
