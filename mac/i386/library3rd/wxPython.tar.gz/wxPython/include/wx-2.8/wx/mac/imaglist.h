#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/imaglist.h"
#else
#include "wx/mac/carbon/imaglist.h"
#endif
