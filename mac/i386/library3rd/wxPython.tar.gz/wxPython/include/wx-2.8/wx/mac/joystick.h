#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/joystick.h"
#else
#include "wx/mac/carbon/joystick.h"
#endif
