#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/macnotfy.h"
#else
#include "wx/mac/carbon/macnotfy.h"
#endif
