#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/mdi.h"
#else
#include "wx/mac/carbon/mdi.h"
#endif
