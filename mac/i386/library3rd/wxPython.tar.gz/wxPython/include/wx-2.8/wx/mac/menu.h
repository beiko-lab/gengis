#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/menu.h"
#else
#include "wx/mac/carbon/menu.h"
#endif
