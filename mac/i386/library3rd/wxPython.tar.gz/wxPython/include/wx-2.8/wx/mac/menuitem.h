#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/menuitem.h"
#else
#include "wx/mac/carbon/menuitem.h"
#endif
