#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/metafile.h"
#else
#include "wx/mac/carbon/metafile.h"
#endif
