#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/msgdlg.h"
#else
#include "wx/mac/carbon/msgdlg.h"
#endif
