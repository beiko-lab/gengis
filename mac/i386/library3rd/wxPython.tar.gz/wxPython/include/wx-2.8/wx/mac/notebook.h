#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/notebook.h"
#else
#include "wx/mac/carbon/notebook.h"
#endif
