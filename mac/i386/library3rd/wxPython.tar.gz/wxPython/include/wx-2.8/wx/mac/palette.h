#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/palette.h"
#else
#include "wx/mac/carbon/palette.h"
#endif
