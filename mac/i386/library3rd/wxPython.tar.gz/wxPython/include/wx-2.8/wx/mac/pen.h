#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/pen.h"
#else
#include "wx/mac/carbon/pen.h"
#endif
