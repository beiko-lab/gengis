#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/pngread.h"
#else
#include "wx/mac/carbon/pngread.h"
#endif
