#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/printdlg.h"
#else
#include "wx/mac/carbon/printdlg.h"
#endif
