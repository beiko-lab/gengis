#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/region.h"
#else
#include "wx/mac/carbon/region.h"
#endif
