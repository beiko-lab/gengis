#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/slider.h"
#else
#include "wx/mac/carbon/slider.h"
#endif
