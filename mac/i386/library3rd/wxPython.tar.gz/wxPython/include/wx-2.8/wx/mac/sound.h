#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/sound.h"
#else
#include "wx/mac/carbon/sound.h"
#endif
