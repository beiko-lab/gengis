#ifdef __WXMAC_CLASSIC__
#include "wx/generic/srchctlg.h"
#else
#include "wx/mac/carbon/srchctrl.h"
#endif
