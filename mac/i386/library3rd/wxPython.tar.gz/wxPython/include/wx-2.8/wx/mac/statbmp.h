#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/statbmp.h"
#else
#include "wx/mac/carbon/statbmp.h"
#endif
