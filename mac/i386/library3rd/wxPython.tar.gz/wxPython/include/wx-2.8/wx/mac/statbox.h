#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/statbox.h"
#else
#include "wx/mac/carbon/statbox.h"
#endif
