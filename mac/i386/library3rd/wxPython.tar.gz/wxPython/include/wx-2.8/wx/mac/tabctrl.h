#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/tabctrl.h"
#else
#include "wx/mac/carbon/tabctrl.h"
#endif
