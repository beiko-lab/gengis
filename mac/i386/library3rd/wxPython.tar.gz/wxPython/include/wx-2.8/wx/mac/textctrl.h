#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/textctrl.h"
#else
#include "wx/mac/carbon/textctrl.h"
#endif
