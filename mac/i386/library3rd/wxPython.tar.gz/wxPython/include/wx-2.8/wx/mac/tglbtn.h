#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/tglbtn.h"
#else
#include "wx/mac/carbon/tglbtn.h"
#endif