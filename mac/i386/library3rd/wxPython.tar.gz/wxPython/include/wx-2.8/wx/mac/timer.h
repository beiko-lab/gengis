#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/timer.h"
#else
#include "wx/mac/carbon/timer.h"
#endif
