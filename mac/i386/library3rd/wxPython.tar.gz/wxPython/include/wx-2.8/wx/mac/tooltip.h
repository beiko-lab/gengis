#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/tooltip.h"
#else
#include "wx/mac/carbon/tooltip.h"
#endif
