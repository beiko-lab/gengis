#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/uma.h"
#else
#include "wx/mac/carbon/uma.h"
#endif
