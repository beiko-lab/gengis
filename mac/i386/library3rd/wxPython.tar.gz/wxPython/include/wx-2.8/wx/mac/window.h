#ifdef __WXMAC_CLASSIC__
#include "wx/mac/classic/window.h"
#else
#include "wx/mac/carbon/window.h"
#endif
