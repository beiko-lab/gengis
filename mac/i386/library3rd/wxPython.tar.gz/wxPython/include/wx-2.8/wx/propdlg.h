/////////////////////////////////////////////////////////////////////////////
// Name:        wx/propdlg.h
// Purpose:     wxPropertySheetDialog base header
// Author:      Julian Smart
// Modified by:
// Created:
// RCS-ID:      $Id: propdlg.h 33948 2005-05-04 18:57:50Z JS $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_PROPDLG_H_BASE_
#define _WX_PROPDLG_H_BASE_

#include "wx/generic/propdlg.h"

#endif
    // _WX_PROPDLG_H_BASE_

